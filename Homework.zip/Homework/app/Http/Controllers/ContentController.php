<?php

namespace App\Http\Controllers;


use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Collection;
use App\Content;
use App\User;

class ContentController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

   public function index($collectionName)
{

  $user_id=Auth::user()->id;
 
  $id_coll=Collection::where('nome_raccolta',$collectionName)
  ->where('user_id',$user_id)->select('id')->get();
  //verifico se la raccolta è associata all'utente
  $contentList = Content::where('id_raccolta',$id_coll[0]->id)->get();
if($id_coll->has('id')){
  $mex=true;
}
 else{
  $mex="false";
 } 
 return view('/collection')->with('contentList',$contentList)->with('mex',$mex);
    
}

public function insertContent(Request $request){ 
      
 if($request->has('artista')&& $request->has('id')&& $request->has('url')&&
 $request->has('raccolta')){ 
     $nome=$request->raccolta;
     $user_id=Auth::user()->id;
     $user=User::find($user_id);
   // $coll_id=$user->collections;//->select('id')->where('name',$nome)->get();
     $coll_id=Collection::join('users', 'users.id', '=', 'collections.user_id')
            ->select('collections.id')->where('nome_raccolta',$nome)->where('users.id',$user_id)
             ->get();
    //Aggiornamento image nelle collections
    Collection::where('id',$coll_id[0]->id)->update(['img_url'=>$request->url]);
    //poiché si può generare un'eccezione che bloccante bisogna gestirla
    try{
      Content::insert(['id_raccolta' => $coll_id[0]->id,'id_contenuto' => $request->id, 'nome_artista' =>$request->artista,
      'img_url' =>  $request->url]);
    }
    catch(\Illuminate\Database\QueryException $e){
      return "false";
    }
    return "true";
     }

     else
    {
      return "false";
    
    }

 }
 public function delete(Request $req){
   //Non è necessario fare il controllo di associazione con la raccolta perché
   //a causa della mia aggiunta dell' id viene automatico il bypass del controllo
Content::where('id',$req->id)->delete();
 }
}