<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SearchController extends Controller
{

     /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function show(){
        return view('\search');
    } 


    public function spotify(Request $request){
    
      // dd($request);

    
            // id e secret del servizio
    $client_id = "27bdb38ca1414198916bd688c392eb31";
    $client_secret = "d989650fd97b42a5b0624197dfe7e9c1";

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, "https://accounts.spotify.com/api/token");
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, "grant_type=client_credentials");
    $headers = array("Authorization: Basic ".base64_encode($client_id.":".$client_secret));
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($curl);
    curl_close($curl);
    
    $token = json_decode($result)->access_token;
    $artista=$request->stringa;
    //$artista=request('stringa');
    //$checkArtista =$request->has('stringa);
    $data = http_build_query(array("q" => $artista, "type" => "artist"));
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, "https://api.spotify.com/v1/search?".$data);
    $headers = array("Authorization: Bearer ".$token);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($curl);
    curl_close($curl);
   // deve ritornare al fetch del js  
   $data = json_decode($result, true);
return empty($data) ? 'invalid address' : $data;
  //  return $result;
    } 
}
