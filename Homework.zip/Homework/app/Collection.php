<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Collection extends Model
{
  // Relazioni
  public function users()
  {
      return $this->belongsTo('User');
  }
  public function composites()
  {
      return $this->hasMany('Content');
  }      
}
