@extends('layouts.layout')
@section('head')
<script src="{{ asset('js/home.js') }}" defer></script>
@endsection

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"> My Collections</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <p>
        <a id='create_coll' href="#">Create new collection</a>
        <main>
        
<form class='hidden0' id="insert_racc" name="insert_raccolta" method="post" action= "{{route("creation")}}">
          @csrf    
           <p>Collection name<label id='input_nome'><input type='text' name='raccolta'></label></p>
               <p><label id='invio'>&nbsp;<input name='submit'type='submit'></label></p>
</form>
</main>
    </p>
    <div class="contenuto">
        @foreach($collectionList as $Collection)
           <div class="item-contenuto">
                <p class="testo" name="testo"> Collection: {{$Collection->nome_raccolta }}</p>
                <img src="{{$Collection->img_url}}" />                
</div>
        @endforeach
</div>


                </div>
            </div>
        </div>
    </div>
</div>
@endsection
