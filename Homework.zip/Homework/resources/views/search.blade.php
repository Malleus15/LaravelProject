@extends('layouts.layout')

@section('head')
<script src="{{ asset('js/search.js') }}" defer></script>
@endsection

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"> Dashboard</div>
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    
 <form method="post" id="in_form" name="in_form" action="{{route("spotify")}}" >
@csrf
<input  type="text" id="stringa" name="stringa" >
<input type='submit' name='invio'>
</form>
<div name='contenuto' id="contenuto">

</div>
<main>
<form method="post" name="insert_raccolta" id="insert_raccolta"  action="{{route("insert")}}">
   @csrf
                <p><label class="hidden0"  id='input_nome' ><input type='text' name='raccolta' value='Nome raccolta'></label></p>
                <p><label class="hidden0" id='artista'><input  type='text' name='artista' value='Nome artista' ></label></p>
                <p><label class="hidden"><input type='text' name='id' ></label></p>
                <p><label class="hidden"><input type='text' name='url'></label></p>
                <p><label class="hidden0" id='invio'>&nbsp;<input name="submit" type='submit'></label></p>
</form>
</main>
</div>
            </div>
        </div>
    </div>
</div>
@endsection