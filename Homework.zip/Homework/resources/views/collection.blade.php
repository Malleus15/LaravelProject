@extends('layouts.layout')

@section('head')
<script src="{{ asset('js/collection.js') }}" defer></script>
@endsection


@section('content')
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
    
                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif
        <div class="contenuto">
                @foreach($contentList as $Content)
                <div class="item-contenuto">
                        <p class=' primary hidden0'>{{$Content->id}}<p>
                                <p class='h5 hidden'> Id: {{$Content->id_contenuto }}</p>
                                <p class="testo"> Artist: {{$Content->nome_artista }}</p>
                                <img src="{{$Content->img_url}}" /> 
                                <button class="butt" name="butt"  >Delete </button>   
        </div>
                @endforeach
    </div>
    
    
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endsection
     <!--Questo p mi evita di recuperareid di spotify e nome della raccolta
                    basta solo l'id primario  -->
    