<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();
//per le mail
Auth::routes(['verify'=> true]);
Route::get('/',function(){
    return view('welcome');
})->middleware('verified');

//Home
Route::get('/home', 'HomeController@index');
//search 
Route::get('/search', 'SearchController@show');
 
Route::post('/search/spotify','SearchController@spotify')->name('spotify');
//eliminazione contenuti
Route::post('/collection/delete', 'ContentController@delete');

Route::post('/collection/creation', 'HomeController@create')->name('createCollection');
//route per visualizzare la pagina collections
Route::get('/collection/{collectionName}', 'ContentController@index')->name('collection');

//route per l'insert del contenuto
Route::post('/collection/insert', 'ContentController@insertContent')->name('insert');
Route::post('/collection/creation', 'HomeController@create')->name('creation');
//
Auth::routes();