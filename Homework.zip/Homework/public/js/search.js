function onResponse(response){
 console.log(response);
    return response.json();
}
function onJsonReady(json) {
  json=JSON.parse(JSON.stringify(json));
  console.log(json);
  /*Immagine di default: in caso di assenza immagini infatti se capita non restituisce i risultati successivi
  o risultati che non hanno immagine, il che è un bel problema per l'utente, difatti il sito non restituirebbe nulla 
  per alcune ricerche*/
  let image="https://images-na.ssl-images-amazon.com/images/I/71hBJHUk4vL._SY550_.jpg";
//per svuotare il contenuto: ad ogni ricerca altrimenti si ottiene un elenco di contenuti con somma ai precedenti
  const container0= document.querySelector("#contenuto");
  container0.innerHTML='';
    for(i in json.artists.items){
      for(j in json.artists.items[i].images){
        //Prende la prima immagine non vuota, trovatala interrompe il ciclo.
      if(json.artists.items[i].images[j].url !== "undefined"||json.artists.items[i].images[j].url!==""){
    image=json.artists.items[i].images[j].url;
    break;
}
}
        const nome = json.artists.items[i].name;
    const id= json.artists.items[i].id;
    const new_div=document.createElement("div");
    new_div.classList.add("ite");
    new_div.textContent=nome;
    const new_id=document.createElement("p");
    new_id.textContent=id;
    new_id.classList.add("id_elem");
    const new_img=document.createElement("img");
    new_img.classList.add("url_img");
    new_img.src=image;
    const container=document.createElement("div");
      container.classList.add("item-contenuto");
      container0.appendChild(container);
      container.appendChild(new_div);
      container.appendChild(new_id);
      container.appendChild(new_img);
      container.addEventListener('click', contentHandler);
    }
    }


    function submitHandler(event)
    {
      event.preventDefault();
        let url=$(this).attr("action");
        let data = new FormData(this);
      
        fetch(url,{body:data,
        method:'post'}).then(onResponse).then(onJsonReady);

      //Restituisc un json vuoto!!!!!
      /*fetch("http://localhost:8000/search/spotify", 
      {
        headers: head,
        method: 'post',
        body: f
      }).then(onResponse).then(onJsonReady);*/
    } 

function contentHandler(event){
  //mostra l'input nome raccolta e artista e anche il submit
  const nome_input = document.querySelector('#input_nome');
  nome_input.classList.remove('hidden0');
  const artist = document.querySelector('#artista');
  artist.classList.remove('hidden0');
  const invio = document.querySelector('#invio');
  invio.classList.remove('hidden0');
  const ev = event.currentTarget;
  //eventualmente un altro click fa cambiare il currentTarget
  ev.addEventListener('click', contentHandler);
  //inserisce i dati nel form non visibile prendendoli dal documento
  const insert_raccolta = document.getElementById('insert_raccolta');
  insert_raccolta.url.value = ev.querySelector("img").src;
  insert_raccolta.id.value = ev.querySelector("p").textContent;
  insert_raccolta.addEventListener('submit', inserimentoDB);
}

function inserimentoDB(event){
  //necessario raddoppiare il prevent
  event.preventDefault();
    let url=$(this).attr("action");
    let data = new FormData(this);
  
    fetch(url,{body:data,
    method:'post'}).then(onResponse1).then(onText);
}
function onText(text){
  console.log(text);
  if(text == "true"){
   alert("Contenuti inseriti con successo!");
  }
  else{
    alert("Errore nell'inserimento di contenuti: verifica che si tratti di una raccolta già creata nella home!\nOppure che il contenuto non sia già presente");
  
  }
   //acquisisce il nome della raccolta e lo nasconde
   const nome_input = document.querySelector('#input_nome');
   nome_input.classList.add('hidden0');
   // fa lo stesso con il bottone e l'artista
   const artista=document.querySelector('#artista');
   artista.classList.add('hidden0');
   const invio = document.querySelector('#invio');
   invio.classList.add('hidden0');
   const insert_raccolta = document.getElementById('insert_raccolta');
   insert_raccolta.addEventListener('submit', inserimentoDB);
  }
function onResponse1(response){
  console.log(response);
  return response.text();
}
const form = document.getElementById("in_form");
form.addEventListener('submit', submitHandler);
/*
$('#in_form').submit(function (event) {
  event.preventDefault();
  var url=$(this).attr("action");
  var data = new FormData(this);

  fetch(url,{body:data,
  method:'post'});
}); Guzzle\Client  */
