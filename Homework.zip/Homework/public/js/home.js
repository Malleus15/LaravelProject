// per la creazione della nuova raccolta
function onText (text){
    console.log(text);
  if(text == "true"){
   alert("Nome inserito con successo!");
  }
  else{
    alert("Errore nell'inserimento di nome raccolta!\nForse hai già usato il nome per creare una raccolta!");
  }
  //per il refresh della pagina e la visualizzazione del nuovo contenuto
  location.reload();
  }
  
  function onResponseRaccolta(response){
    return response.text();
  }
  
  function inserimentoDB(event){
     //necessario raddoppiare il prevent
     event.preventDefault();
      let url=$(this).attr("action");
      let data = new FormData(this);
    
      fetch(url,{body:data,
      method:'post'}).then(onResponseRaccolta).then(onText);
     
  }
  
  function collection(event){
    console.log(event);
   const ev = event.currentTarget;
    const value= ev.textContent;
    //per prendere solo il valore nome raccolta
    let val=value.replace("Collection:","");
    //uso il metodo trim per eliminare gli spazi che crea
     val=val.trim();
    url="http://localhost:8000/collection/"+val;
    window.location.href=url;
  
  }
 
  function createColl(){
    const form = document.querySelector('#insert_racc');
    form.classList.remove('hidden0');
    form.addEventListener('submit', inserimentoDB);
  }
  //listeners per il box necessari perche altrimenti si associa il listener solo ad un item
let elem = document.querySelectorAll(".item-contenuto");
for(let i = 0; i < elem.length; i++){
  elem[i].addEventListener("click", collection);

}
  document.querySelector("#create_coll").addEventListener('click', createColl);