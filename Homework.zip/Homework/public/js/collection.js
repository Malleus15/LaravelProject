/** per questioni di inutile ripetizione di codice e per evitare aggiunta di routes
 * ho deciso di mostrare il contenuto reperito con una semplice query 
 * contestualmente al caricamento della pagina
 *  */

function mostra(event){
    console.log("MOSTRA");
    const ev = event.currentTarget;
    ev.querySelector(".h5").classList.remove("hidden");
    ev.addEventListener('click', nascondi);
    ev.removeEventListener('click', mostra);
}

function nascondi(event){
    console.log("NASCONDI");
    const ev= event.currentTarget;
    ev.querySelector(".h5").classList.add("hidden");
    ev.addEventListener('click', mostra);
}
//al completamento dell' eliminazione bisogna ricaricare
function ricaricamento(){
    location.reload();
}

function cancella(event){
    console.log("CANCELLA");
    const parent= event.currentTarget.parentNode;
    const form = new FormData();
   const id = parent.querySelector('.primary').textContent;   
            form.append('id',id);
            
        let token = $('meta[name="csrf-token"]').attr('content');

            const url="http://localhost:8000/collection/delete";
   fetch(url, { method: 'POST', headers: {
    'X-CSRF-Token': token
  }, body: form }).then(ricaricamento);
}

//aggiunge gli eventListener a tutti gli item e button
const container= document.querySelectorAll('.item-contenuto');
const butt=document.querySelectorAll('.butt');
for(let i = 0; i < container.length; i++){
    container[i].addEventListener("click", mostra);
    butt[i].addEventListener('click', cancella);
  }