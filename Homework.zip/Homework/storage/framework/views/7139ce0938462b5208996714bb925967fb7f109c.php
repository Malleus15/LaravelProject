<?php $__env->startSection('head'); ?>
<script src="<?php echo e(asset('js/home.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"> My Collections</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <p>
        <a id='create_coll' href="#">Create new collection</a>
        <main>
        
<form class='hidden0' id="insert_racc" name="insert_raccolta" method="post" action= "<?php echo e(route("creation")); ?>">
          <?php echo csrf_field(); ?>    
           <p>Collection name<label id='input_nome'><input type='text' name='raccolta'></label></p>
               <p><label id='invio'>&nbsp;<input name='submit'type='submit'></label></p>
</form>
</main>
    </p>
    <div class="contenuto">
        <?php $__currentLoopData = $collectionList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="item-contenuto">
                <p class="testo" name="testo"> Collection: <?php echo e($Collection->nome_raccolta); ?></p>
                <img src="<?php echo e($Collection->img_url); ?>" />                
</div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Homework\resources\views//home.blade.php ENDPATH**/ ?>