<?php $__env->startSection('head'); ?>
<script src="<?php echo e(asset('js/search.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"> Dashboard</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
 <form method="post" id="in_form" name="in_form" action="<?php echo e(route("spotify")); ?>" >
<?php echo csrf_field(); ?>
<input  type="text" id="stringa" name="stringa" >
<input type='submit' name='invio'>
</form>
<div name='contenuto' id="contenuto">

</div>
<main>
<form method="post" name="insert_raccolta" id="insert_raccolta"  action="<?php echo e(route("insert")); ?>">
   <?php echo csrf_field(); ?>
                <p><label class="hidden0"  id='input_nome' ><input type='text' name='raccolta' value='Nome raccolta'></label></p>
                <p><label class="hidden0" id='artista'><input  type='text' name='artista' value='Nome artista' ></label></p>
                <p><label class="hidden"><input type='text' name='id' ></label></p>
                <p><label class="hidden"><input type='text' name='url'></label></p>
                <p><label class="hidden0" id='invio'>&nbsp;<input name="submit" type='submit'></label></p>
</form>
</main>
</div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Homework\resources\views/\search.blade.php ENDPATH**/ ?>