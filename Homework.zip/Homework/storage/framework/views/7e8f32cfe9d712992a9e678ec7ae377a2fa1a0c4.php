<?php $__env->startSection('head'); ?>
<script src="<?php echo e(asset('js/collection.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
    
                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
        <div class="contenuto">
                <?php $__currentLoopData = $contentList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item-contenuto">
                        <p class=' primary hidden0'><?php echo e($Content->id); ?><p>
                                <p class='h5 hidden'> Id: <?php echo e($Content->id_contenuto); ?></p>
                                <p class="testo"> Artist: <?php echo e($Content->nome_artista); ?></p>
                                <img src="<?php echo e($Content->img_url); ?>" /> 
                                <button class="butt" name="butt"  >Delete </button>   
        </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
     <!--Questo p mi evita di recuperareid di spotify e nome della raccolta
                    basta solo l'id primario  -->
    
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Homework\resources\views//collection.blade.php ENDPATH**/ ?>