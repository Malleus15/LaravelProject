<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"> My Collections</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <p>
        <a href="<?php echo e(route('collection.create')); ?>">Create new collection</a>
    </p>
    <table class="table">
        <?php $__currentLoopData = $CollectionList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($Collection->nome_raccolta); ?></td>
                <img src="<?php echo e($Collection->img_url); ?>" />
                <td>
                    <a class="btn btn-default" href="<?php echo e(route('collection.edit', ['collection' => $Collection->id])); ?>">Modifica</a>
                </td>
                <td>
                    <?php echo Form::open(['route' => ['collection.destroy', $Collection->id], 'method' => 'delete' ]); ?>

                        <?php echo Form::submit('Elimina', ['class' => 'btn btn-danger']); ?>

                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Homework\resources\views/home.blade.php ENDPATH**/ ?>