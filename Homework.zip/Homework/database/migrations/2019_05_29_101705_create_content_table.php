<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateContentTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('contents', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('id_contenuto');
            $table->string('nome_artista');
            $table->unsignedBigInteger('id_raccolta');
            $table->string('img_url');
            $table->timestamps();
            $table->unique('id_contenuto','id_raccolta');
//Uso id in più perché non è supportata primary key composta
            $table->foreign('id_raccolta')->references('id')->on('collections')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('contents');
    }
}
