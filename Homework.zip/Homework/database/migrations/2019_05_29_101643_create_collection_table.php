<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCollectionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('collections', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('nome_raccolta');
            $table->unsignedBigInteger('user_id');
            //Immagine di default per le raccolte
            $value="https://images-na.ssl-images-amazon.com/images/I/71hBJHUk4vL._SY550_.jpg";
            $table->string('img_url')->default($value);
            $table->timestamps();
            //definisco user_id foreign key
            $table->unique('nome_raccolta','user_id');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('collections');
    }
}
